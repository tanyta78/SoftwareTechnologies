<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_74054fcf4bd88e3b7d9ad86aff007ed1feda794d6be727ec678b20b99637d7a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0491f9387964795fe76dde828e5cdcfbc1c7d83a478d68029048cee2cd00c266 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0491f9387964795fe76dde828e5cdcfbc1c7d83a478d68029048cee2cd00c266->enter($__internal_0491f9387964795fe76dde828e5cdcfbc1c7d83a478d68029048cee2cd00c266_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0491f9387964795fe76dde828e5cdcfbc1c7d83a478d68029048cee2cd00c266->leave($__internal_0491f9387964795fe76dde828e5cdcfbc1c7d83a478d68029048cee2cd00c266_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_5ffdd041d927ee68fb980e9b728219d1f81ad6be87a1001e7e2788d4b022a61a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ffdd041d927ee68fb980e9b728219d1f81ad6be87a1001e7e2788d4b022a61a->enter($__internal_5ffdd041d927ee68fb980e9b728219d1f81ad6be87a1001e7e2788d4b022a61a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_5ffdd041d927ee68fb980e9b728219d1f81ad6be87a1001e7e2788d4b022a61a->leave($__internal_5ffdd041d927ee68fb980e9b728219d1f81ad6be87a1001e7e2788d4b022a61a_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b53e698e926b1c391b3ed9419af3058d1455e69bff8b10a942877ddb8c59a1b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b53e698e926b1c391b3ed9419af3058d1455e69bff8b10a942877ddb8c59a1b2->enter($__internal_b53e698e926b1c391b3ed9419af3058d1455e69bff8b10a942877ddb8c59a1b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_b53e698e926b1c391b3ed9419af3058d1455e69bff8b10a942877ddb8c59a1b2->leave($__internal_b53e698e926b1c391b3ed9419af3058d1455e69bff8b10a942877ddb8c59a1b2_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_e5b4bf8476e47026692734b9fff74fb4a07cafa3fe524027274825bee5604bba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5b4bf8476e47026692734b9fff74fb4a07cafa3fe524027274825bee5604bba->enter($__internal_e5b4bf8476e47026692734b9fff74fb4a07cafa3fe524027274825bee5604bba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_e5b4bf8476e47026692734b9fff74fb4a07cafa3fe524027274825bee5604bba->leave($__internal_e5b4bf8476e47026692734b9fff74fb4a07cafa3fe524027274825bee5604bba_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
