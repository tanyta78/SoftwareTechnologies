<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_0273f364a5321caa87332c6a47b15f0546c9a0ed56859e0d4fee76895c5e3535 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e6cfaa96f446daf911cab1462bbea700a1807b76d5e15f12833933377b501578 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6cfaa96f446daf911cab1462bbea700a1807b76d5e15f12833933377b501578->enter($__internal_e6cfaa96f446daf911cab1462bbea700a1807b76d5e15f12833933377b501578_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_e6cfaa96f446daf911cab1462bbea700a1807b76d5e15f12833933377b501578->leave($__internal_e6cfaa96f446daf911cab1462bbea700a1807b76d5e15f12833933377b501578_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
    }
}
