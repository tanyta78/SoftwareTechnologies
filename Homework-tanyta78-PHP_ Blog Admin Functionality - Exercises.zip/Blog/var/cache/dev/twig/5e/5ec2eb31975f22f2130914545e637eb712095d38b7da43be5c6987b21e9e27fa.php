<?php

/* form/fields.html.twig */
class __TwigTemplate_12417f7b5793e82faac035ac41b1659b3531eb4730fc98ae2368636b69f6a28a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'date_time_picker_widget' => array($this, 'block_date_time_picker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af5121301855aba71585509c716b3c5d797170ecb9ad6af200ea4bd22f36d0f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af5121301855aba71585509c716b3c5d797170ecb9ad6af200ea4bd22f36d0f4->enter($__internal_af5121301855aba71585509c716b3c5d797170ecb9ad6af200ea4bd22f36d0f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        // line 9
        echo "
";
        // line 10
        $this->displayBlock('date_time_picker_widget', $context, $blocks);
        
        $__internal_af5121301855aba71585509c716b3c5d797170ecb9ad6af200ea4bd22f36d0f4->leave($__internal_af5121301855aba71585509c716b3c5d797170ecb9ad6af200ea4bd22f36d0f4_prof);

    }

    public function block_date_time_picker_widget($context, array $blocks = array())
    {
        $__internal_1124d0bf1515fc5c070818de641c0aae1500a3349f80319efc9f1e38dde34366 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1124d0bf1515fc5c070818de641c0aae1500a3349f80319efc9f1e38dde34366->enter($__internal_1124d0bf1515fc5c070818de641c0aae1500a3349f80319efc9f1e38dde34366_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        // line 11
        echo "    ";
        ob_start();
        // line 12
        echo "        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            ";
        // line 13
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
            ";
        // line 15
        echo "                ";
        // line 16
        echo "            ";
        // line 17
        echo "        </div>
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_1124d0bf1515fc5c070818de641c0aae1500a3349f80319efc9f1e38dde34366->leave($__internal_1124d0bf1515fc5c070818de641c0aae1500a3349f80319efc9f1e38dde34366_prof);

    }

    public function getTemplateName()
    {
        return "form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  52 => 17,  50 => 16,  48 => 15,  44 => 13,  41 => 12,  38 => 11,  26 => 10,  23 => 9,);
    }

    public function getSource()
    {
        return "{#
   Each field type is rendered by a template fragment, which is determined
   by the name of your form type class (DateTimePickerType -> date_time_picker)
   and the suffix \"_widget\". This can be controlled by overriding getBlockPrefix()
   in DateTimePickerType.

   See http://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field
#}

{% block date_time_picker_widget %}
    {% spaceless %}
        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            {{ block('datetime_widget') }}
            {#<span class=\"input-group-addon\">#}
                {#<span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>#}
            {#</span>#}
        </div>
    {% endspaceless %}
{% endblock %}
";
    }
}
