<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_71e2996cb7bf8a49523e325c392a6e51043a8e18aa9153e6892bd8a42deeb902 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cb1a4b4a7fa1ea3b8664d1711841e7f44ea3355b08fe93de033da48b94ed8906 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb1a4b4a7fa1ea3b8664d1711841e7f44ea3355b08fe93de033da48b94ed8906->enter($__internal_cb1a4b4a7fa1ea3b8664d1711841e7f44ea3355b08fe93de033da48b94ed8906_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_cb1a4b4a7fa1ea3b8664d1711841e7f44ea3355b08fe93de033da48b94ed8906->leave($__internal_cb1a4b4a7fa1ea3b8664d1711841e7f44ea3355b08fe93de033da48b94ed8906_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->widget(\$form) ?>
";
    }
}
