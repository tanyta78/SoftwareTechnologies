<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_114b52ae6e2973d19e424ea4741de338568e662499c03d8ac34fe8811dbb83e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f5b66ac070913ef68f820586f83759f9d7b79af91eaf274cd0bc5bcac0c309ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5b66ac070913ef68f820586f83759f9d7b79af91eaf274cd0bc5bcac0c309ad->enter($__internal_f5b66ac070913ef68f820586f83759f9d7b79af91eaf274cd0bc5bcac0c309ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_f5b66ac070913ef68f820586f83759f9d7b79af91eaf274cd0bc5bcac0c309ad->leave($__internal_f5b66ac070913ef68f820586f83759f9d7b79af91eaf274cd0bc5bcac0c309ad_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSource()
    {
        return "";
    }
}
